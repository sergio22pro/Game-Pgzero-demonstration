import random

TITLE = "intro"
WIDTH = 600
HEIGHT = 400

square = Rect((100, 100), (50, 50))
score = 0

def draw():
    screen.clear()
    screen.fill((200, 200, 200))
    screen.draw.filled_rect(square, "red")
    screen.draw.text(f"Pontos: {score}", (10, 10), fontsize=40, color="black")

def on_mouse_down(pos):
    global score
    if square.collidepoint(pos):
        score += 1

        square.x = random.randint(0, WIDTH - square.width)
        square.y = random.randint(0, HEIGHT - square.height)